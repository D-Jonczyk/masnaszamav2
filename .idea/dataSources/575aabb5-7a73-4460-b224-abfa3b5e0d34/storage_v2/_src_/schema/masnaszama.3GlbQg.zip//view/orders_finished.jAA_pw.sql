create definer = masnaszamauser@`%` view orders_finished as
select `o`.`order_id`                                                                             AS `order_id`,
       `co`.`courier_id`                                                                          AS `courier_id`,
       `o`.`order_price`                                                                          AS `order_price`,
       `r`.`restaurant_name`                                                                      AS `resto_name`,
       concat(`ad`.`street`, ' ', `ad`.`flat_number`)                                             AS `customer_address`,
       `cu`.`phonenumber`                                                                         AS `phonenumber`,
       date_format(`o`.`ordered_time`, '%T')                                                      AS `ordered_time`,
       date_format(`o`.`desired_delivery_time`, '%T')                                             AS `desired_delivery_time`,
       date_format(addtime(`o`.`desired_delivery_time`, ((rand() * (200 + -(200))) - 200)), '%T') AS `delivered_time`
from ((((((`masnaszama`.`couriers_orders` `co` join `masnaszama`.`order_` `o` on ((`o`.`order_id` = `co`.`order_id`))) join `masnaszama`.`status_` `s` on ((`o`.`status_id` = `s`.`status_id`))) join `masnaszama`.`courier` `c` on ((`co`.`courier_id` = `c`.`id`))) join `masnaszama`.`restaurant` `r` on ((`o`.`restaurant_id` = `r`.`restaurant_id`))) join `masnaszama`.`customer` `cu` on ((`o`.`customer_id` = `cu`.`id`)))
         join `masnaszama`.`address` `ad` on ((`cu`.`address_id` = `ad`.`address_id`)))
where (`s`.`status_name` like 'finished');

