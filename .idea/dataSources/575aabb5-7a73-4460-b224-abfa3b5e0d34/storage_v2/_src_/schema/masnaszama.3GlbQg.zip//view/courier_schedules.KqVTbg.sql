create definer = masnaszamauser@`%` view courier_schedules as
select `s`.`schedule_id` AS `schedule_id`,
       `s`.`start_time`  AS `start_time`,
       `s`.`end_time`    AS `end_time`,
       `s`.`full_date`   AS `full_date`,
       `es`.`person_id`  AS `courier_id`,
       `s`.`week_number` AS `week_number`
from ((`masnaszama`.`schedule` `s` join `masnaszama`.`employees_schedules` `es` on ((`s`.`schedule_id` = `es`.`schedule_id`)))
         join `masnaszama`.`courier` `c` on ((`es`.`person_id` = `c`.`id`)));

